// This program will write the name, address and telephone
// number of the programmer.

// PLACE YOUR NAME HERE

#include <iostream>
using namespace std;

int main()
{
	// Fill in this space to write your first and last name
	// Fill in this space to write your address (on new line)
	// Fill in this space to write you city, state and zip (on new line)
	// Fill in this space to write your telephone number (on new line)

	return 0;
}